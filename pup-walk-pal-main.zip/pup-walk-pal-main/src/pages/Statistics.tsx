
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { 
  Bar, 
  BarChart, 
  CartesianGrid, 
  Legend, 
  ResponsiveContainer, 
  Tooltip, 
  XAxis, 
  YAxis,
  PieChart,
  Pie,
  Cell 
} from 'recharts';

const Statistics = () => {
  const { state } = useApp();
  const navigate = useNavigate();
  
  // Redirect to registration if not registered
  useEffect(() => {
    if (!state.isRegistered) {
      navigate('/register');
    }
  }, [state.isRegistered, navigate]);
  
  // Sort members by walk count (most walks first)
  const sortedMembers = [...state.members].sort((a, b) => b.walkCount - a.walkCount);
  
  // Format data for the pie chart (walk distribution)
  const walkDistributionData = state.members.map(member => ({
    name: member.name,
    value: member.walkCount,
  }));
  
  // Format data for the bar chart (walk duration)
  const walkDurationData = state.members.map(member => ({
    name: member.name,
    duration: Math.round(member.totalWalkDuration / (member.walkCount || 1)), // Average duration
  }));
  
  // Total household stats
  const totalHouseholdWalks = state.members.reduce((sum, member) => sum + member.walkCount, 0);
  const totalHouseholdDuration = state.members.reduce((sum, member) => sum + member.totalWalkDuration, 0);
  const avgWalkDuration = Math.round(totalHouseholdDuration / (totalHouseholdWalks || 1));
  
  // Colors for pie chart
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6 mt-16 mb-20">
        <h1 className="text-2xl font-bold mb-1 animate-enter">
          Statistics & Insights
        </h1>
        <p className="text-gray-500 mb-6 animate-enter animation-delay-100">
          Track your household's walking performance over time.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
            <h2 className="font-semibold mb-4">Household Summary</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-500 text-sm">Total Walks</p>
                <p className="text-2xl font-bold">{totalHouseholdWalks}</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-500 text-sm">Avg. Duration</p>
                <p className="text-2xl font-bold">{avgWalkDuration} min</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
            <h2 className="font-semibold mb-4">Top Walker</h2>
            {sortedMembers.length > 0 ? (
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-4">
                  {sortedMembers[0].name.charAt(0)}
                </div>
                <div>
                  <p className="font-medium">{sortedMembers[0].name}</p>
                  <p className="text-gray-500 text-sm">{sortedMembers[0].walkCount} walks • {sortedMembers[0].totalWalkDuration} minutes</p>
                </div>
              </div>
            ) : (
              <p className="text-gray-500">No walks recorded yet</p>
            )}
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
            <h2 className="font-semibold mb-4">Walk Distribution</h2>
            {totalHouseholdWalks > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={walkDistributionData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {walkDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center">
                <p className="text-gray-500">No walks recorded yet</p>
              </div>
            )}
          </div>
          
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
            <h2 className="font-semibold mb-4">Average Walk Duration</h2>
            {totalHouseholdWalks > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={walkDurationData}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis label={{ value: 'Minutes', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Bar dataKey="duration" fill="#3b82f6" name="Avg. Minutes" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center">
                <p className="text-gray-500">No walks recorded yet</p>
              </div>
            )}
          </div>
          
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
            <h2 className="font-semibold mb-4">Member Achievements</h2>
            {sortedMembers.length > 0 ? (
              <div className="space-y-3">
                {sortedMembers.map(member => (
                  <div key={member.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-3">
                        {member.name.charAt(0)}
                      </div>
                      <span className="font-medium">{member.name}</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {member.achievements.length > 0 ? (
                        member.achievements.map((achievement, index) => (
                          <span 
                            key={index} 
                            className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full"
                          >
                            {achievement}
                          </span>
                        ))
                      ) : (
                        <span className="text-xs text-gray-500">No achievements yet</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No members added yet</p>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Statistics;
