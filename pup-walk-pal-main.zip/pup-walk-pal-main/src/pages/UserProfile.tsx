
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { User, Mail, Save } from 'lucide-react';
import { HouseholdMember } from '@/context/types';
import { toast } from 'sonner';

const UserProfile = () => {
  const { state, updateState } = useApp();
  const navigate = useNavigate();
  
  const currentMember = state.members.find(m => m.id === state.currentUser);
  
  const [profile, setProfile] = useState<HouseholdMember>(
    currentMember || {
      id: '',
      name: '',
      email: '',
      role: '',
      walkCount: 0,
      totalWalkDuration: 0,
      achievements: []
    }
  );
  
  const handleChange = (field: keyof HouseholdMember, value: string) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Update the member in the members array
    const updatedMembers = state.members.map(member => 
      member.id === state.currentUser ? profile : member
    );
    
    updateState({ members: updatedMembers });
    toast.success("Profile updated successfully!");
    navigate('/settings');
  };
  
  if (!currentMember) {
    return <div>Loading...</div>;
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6 mt-16 mb-20">
        <h1 className="text-2xl font-bold mb-1">
          Edit Profile
        </h1>
        <p className="text-gray-500 mb-6">
          Update your personal information
        </p>
        
        <Card className="p-6">
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Name
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-gray-400" />
                  </div>
                  <Input
                    type="text"
                    className="pl-10"
                    value={profile.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email (Optional)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <Input
                    type="email"
                    className="pl-10"
                    value={profile.email || ''}
                    onChange={(e) => handleChange('email', e.target.value)}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Role
                </label>
                <select
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  value={profile.role}
                  onChange={(e) => handleChange('role', e.target.value)}
                  required
                >
                  <option value="Primary">Primary (Main caretaker)</option>
                  <option value="Secondary">Secondary (Regular walker)</option>
                  <option value="Occasional">Occasional (Backup walker)</option>
                </select>
              </div>
              
              <div className="pt-4">
                <Button type="submit" className="w-full">
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </Button>
              </div>
            </div>
          </form>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default UserProfile;
