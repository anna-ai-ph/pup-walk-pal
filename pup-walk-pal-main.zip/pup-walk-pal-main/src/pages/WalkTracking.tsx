import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { WalkTimer } from '@/components/WalkTimer';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Check, AlertTriangle } from 'lucide-react';
import { DogMood, WalkActivityData } from '@/context/types';

const WalkTracking = () => {
  const { state, startWalk, endWalk, getTodaysWalk } = useApp();
  const navigate = useNavigate();
  const todaysWalk = getTodaysWalk();
  
  const [walkInProgress, setWalkInProgress] = useState(!!state.currentWalk);
  const [completionForm, setCompletionForm] = useState(false);
  const [activity, setActivity] = useState<WalkActivityData>({
    peed: false,
    pooped: false,
    notes: '',
    unusualBehavior: [],
  });
  const [dogMood, setDogMood] = useState<DogMood>('Happy');
  
  useEffect(() => {
    if (!state.currentWalk && !todaysWalk && !completionForm) {
      navigate('/');
    }
  }, [state.currentWalk, todaysWalk, navigate, completionForm]);
  
  const handleStartWalk = () => {
    if (todaysWalk) {
      startWalk(todaysWalk.id);
      setWalkInProgress(true);
    }
  };
  
  const handleCompleteWalk = () => {
    setCompletionForm(true);
  };
  
  const handleSubmitCompletion = () => {
    endWalk({
      activity,
      dogMood,
    });
    navigate('/');
  };
  
  const moods: { value: DogMood; label: string; icon: string }[] = [
    { value: 'Happy', label: 'Happy', icon: '😊' },
    { value: 'Calm', label: 'Calm', icon: '😌' },
    { value: 'Tired', label: 'Tired', icon: '😴' },
    { value: 'Stressed', label: 'Stressed', icon: '😟' },
  ];
  
  const toggleUnusualBehavior = (behavior: string) => {
    setActivity(prev => {
      const unusualBehavior = prev.unusualBehavior || [];
      if (unusualBehavior.includes(behavior)) {
        return {
          ...prev,
          unusualBehavior: unusualBehavior.filter(b => b !== behavior),
        };
      } else {
        return {
          ...prev,
          unusualBehavior: [...unusualBehavior, behavior],
        };
      }
    });
  };
  
  if (!walkInProgress && !completionForm) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        
        <main className="container mx-auto px-4 py-6 mt-16 mb-20">
          <h1 className="text-2xl font-bold mb-1 animate-enter">Walk Checklist</h1>
          <p className="text-gray-500 mb-6 animate-enter animation-delay-100">
            Make sure you have everything before heading out with {state.dog.name}.
          </p>
          
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 animate-enter animation-delay-200">
            <h3 className="font-medium text-gray-700 mb-4">Essential Items</h3>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50">
                <Checkbox id="leash" defaultChecked />
                <div>
                  <label
                    htmlFor="leash"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Leash
                  </label>
                  <p className="text-sm text-gray-500">
                    Required for safety and control
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50">
                <Checkbox id="wasteBags" defaultChecked />
                <div>
                  <label
                    htmlFor="wasteBags"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Waste Bags
                  </label>
                  <p className="text-sm text-gray-500">
                    Always clean up after your dog
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50">
                <Checkbox id="water" />
                <div>
                  <label
                    htmlFor="water"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Water Bottle
                  </label>
                  <p className="text-sm text-gray-500">
                    Recommended for longer walks
                  </p>
                </div>
              </div>
            </div>
            
            <Button 
              onClick={handleStartWalk}
              className="w-full"
            >
              Start Walk
            </Button>
          </div>
        </main>
        
        <Footer />
      </div>
    );
  }
  
  if (completionForm) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        
        <main className="container mx-auto px-4 py-6 mt-16 mb-20">
          <h1 className="text-2xl font-bold mb-1 animate-enter">Walk Complete</h1>
          <p className="text-gray-500 mb-6 animate-enter animation-delay-100">
            Tell us about {state.dog.name}'s walk.
          </p>
          
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 animate-enter animation-delay-200">
            <h3 className="font-medium text-gray-700 mb-4">Activity Details</h3>
            
            <div className="space-y-4 mb-6">
              <div className="flex space-x-4">
                <div 
                  className={`flex-1 p-3 rounded-lg border ${activity.peed ? 'bg-yellow-50 border-yellow-200' : 'bg-gray-50 border-gray-200'} cursor-pointer`}
                  onClick={() => setActivity({ ...activity, peed: !activity.peed })}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Peed</span>
                    {activity.peed && <Check size={16} className="text-yellow-500" />}
                  </div>
                </div>
                
                <div 
                  className={`flex-1 p-3 rounded-lg border ${activity.pooped ? 'bg-amber-50 border-amber-200' : 'bg-gray-50 border-gray-200'} cursor-pointer`}
                  onClick={() => setActivity({ ...activity, pooped: !activity.pooped })}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Pooped</span>
                    {activity.pooped && <Check size={16} className="text-amber-500" />}
                  </div>
                </div>
              </div>
              
              <div className="p-3 rounded-lg bg-gray-50 border border-gray-200">
                <label className="block text-sm font-medium mb-2">
                  Any unusual behavior?
                </label>
                
                <div className="space-y-2">
                  {['Low energy', 'Refusal to walk', 'Excessive pulling', 'Fearful reactions'].map((behavior) => (
                    <div key={behavior} className="flex items-center space-x-2">
                      <Checkbox 
                        id={behavior} 
                        checked={activity.unusualBehavior?.includes(behavior) || false}
                        onCheckedChange={() => toggleUnusualBehavior(behavior)}
                      />
                      <label
                        htmlFor={behavior}
                        className="text-sm cursor-pointer"
                      >
                        {behavior}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">
                  How was {state.dog.name}'s mood?
                </label>
                
                <div className="grid grid-cols-4 gap-2">
                  {moods.map((mood) => (
                    <div
                      key={mood.value}
                      className={`p-3 rounded-lg border text-center cursor-pointer transition-colors ${
                        dogMood === mood.value 
                          ? 'bg-primary/10 border-primary/30' 
                          : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                      }`}
                      onClick={() => setDogMood(mood.value)}
                    >
                      <div className="text-2xl mb-1">{mood.icon}</div>
                      <div className="text-sm font-medium">{mood.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <Button 
              onClick={handleSubmitCompletion}
              className="w-full"
            >
              Save Walk
            </Button>
          </div>
        </main>
        
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6 mt-16 mb-20">
        <h1 className="text-2xl font-bold mb-1 animate-enter">Track Walk</h1>
        <p className="text-gray-500 mb-6 animate-enter animation-delay-100">
          Walking {state.dog.name}
        </p>
        
        <div className="space-y-4">
          <WalkTimer onComplete={handleCompleteWalk} />
          
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 animate-enter animation-delay-200">
            <h3 className="font-medium text-gray-700 mb-3">Quick Actions</h3>
            
            <div className="space-y-3">
              <div 
                className={`p-3 rounded-lg border ${activity.peed ? 'bg-yellow-50 border-yellow-200' : 'bg-gray-50 border-gray-200'} cursor-pointer`}
                onClick={() => setActivity({ ...activity, peed: !activity.peed })}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">
                    {activity.peed ? "Peed ✓" : "Mark if dog pees"}
                  </span>
                  {activity.peed && <Check size={16} className="text-yellow-500" />}
                </div>
              </div>
              
              <div 
                className={`p-3 rounded-lg border ${activity.pooped ? 'bg-amber-50 border-amber-200' : 'bg-gray-50 border-gray-200'} cursor-pointer`}
                onClick={() => setActivity({ ...activity, pooped: !activity.pooped })}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">
                    {activity.pooped ? "Pooped ✓" : "Mark if dog poops"}
                  </span>
                  {activity.pooped && <Check size={16} className="text-amber-500" />}
                </div>
              </div>
              
              <div 
                className={`p-3 rounded-lg border ${
                  activity.unusualBehavior && activity.unusualBehavior.length > 0 
                    ? 'bg-red-50 border-red-200' 
                    : 'bg-gray-50 border-gray-200'
                } cursor-pointer`}
                onClick={() => toggleUnusualBehavior('Low energy')}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <AlertTriangle size={16} className="mr-2 text-gray-500" />
                    <span className="font-medium">Unusual behavior</span>
                  </div>
                  {activity.unusualBehavior && activity.unusualBehavior.length > 0 && (
                    <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full">
                      {activity.unusualBehavior.length}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default WalkTracking;
