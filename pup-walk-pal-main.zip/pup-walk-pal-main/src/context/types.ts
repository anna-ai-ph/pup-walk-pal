
export type HouseholdMember = {
  id: string;
  name: string;
  email?: string;
  profilePicture?: string;
  role: string;
  walkCount: number;
  totalWalkDuration: number; // in minutes
  achievements: string[];
};

export type DogProfile = {
  name: string;
  breed: string;
  age: number;
  weight: number;
  energyLevel?: 'Low' | 'Medium' | 'High';
  specialNeeds?: string;
};

export type DogMood = 'Happy' | 'Tired' | 'Excited' | 'Relaxed' | 'Calm' | 'Stressed';

export type WalkActivityData = {
  peed: boolean;
  pooped: boolean;
  notes?: string;
  unusualBehavior?: string[];
  [key: string]: any; // Add index signature to make it compatible with Json type
}

export type WalkActivity = 'Light' | 'Moderate' | 'Intense' | 'Play';
export type WalkStatus = 'Not Started' | 'In Progress' | 'Completed' | 'Confirmed' | 'Canceled' | 'Swap Requested';

export type Walk = {
  id: string;
  date: Date;
  assignedTo: string;
  status: WalkStatus;
  startTime?: Date;
  endTime?: Date;
  duration?: number; // in minutes
  activity?: WalkActivityData;
  dogMood?: DogMood;
  notes?: string;
  swapRequestedBy?: string; // ID of the member who requested a swap
};

export type NotificationType = 
  | 'walk_completed' 
  | 'walk_missed'
  | 'walk_scheduled'
  | 'cover_request'
  | 'walk_reminder'
  | 'achievement'
  | 'system'
  | 'walk_swap_request'  // New notification type for walk swap requests
  | 'walk_swap_accepted'; // New notification type for when a swap is accepted

export type Notification = {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  time: Date;
  read: boolean;
  relatedId?: string; // ID of related entity (walk ID, member ID, etc.)
  acceptedBy?: string; // ID of the member who accepted the swap
};

export type AppState = {
  isRegistered: boolean;
  householdName: string;
  householdId?: string; // Used to track the household across devices
  dog: DogProfile;
  members: HouseholdMember[];
  walks: Walk[];
  currentUser: string;
  currentWalk: Walk | null;
  rememberMe?: boolean; // Added for login persistence
  notifications: Notification[]; // Added for notifications
};

export type AppContextType = {
  state: AppState;
  isLoading: boolean;
  updateState: (newState: Partial<AppState>) => void;
  startWalk: (walkId: string) => void;
  endWalk: (walkData: { activity: WalkActivityData; dogMood: DogMood }) => void;
  requestWalkCover: (walkId: string) => void;
  requestWalkSwap: (walkId: string) => void; // New function to request a temporary walk swap
  acceptWalkSwap: (notificationId: string, walkId: string) => void; // New function to accept a walk swap
  getTodaysWalk: () => Walk | null;
  getWalkerName: (walkerId: string) => string;
  getMemberById: (id: string) => HouseholdMember | undefined;
  registerHousehold: (data: {
    householdName: string;
    password: string;
    dog: DogProfile;
    members: Omit<HouseholdMember, 'walkCount' | 'totalWalkDuration' | 'achievements'>[];
  }) => void;
  confirmWalk: (walkId: string) => void;
  logoutUser: () => void;
  switchUser: (userId: string) => void;
  loginUser: (householdName: string, password: string, userId: string, rememberMe?: boolean) => Promise<boolean>;
  addFamilyMember: (newMember: Omit<HouseholdMember, 'walkCount' | 'totalWalkDuration' | 'achievements'>) => Promise<HouseholdMember>;
  removeFamilyMember: (memberId: string) => Promise<boolean>;
  markNotificationAsRead: (notificationId: string) => void;
  markAllNotificationsAsRead: () => void;
  getUnreadNotificationsCount: () => number;
};
