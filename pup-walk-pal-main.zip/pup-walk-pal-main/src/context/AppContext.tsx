
// This file is maintained for backward compatibility
// It re-exports everything from the new modular structure

export * from './types';
export * from './AppContext';
export * from './AppProvider';
export * from './mockData';
