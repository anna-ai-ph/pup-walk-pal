
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.04e7a341310842dfa52b31e78223c131',
  appName: 'pup-walk-pal',
  webDir: 'dist',
  server: {
    url: "https://04e7a341-3108-42df-a52b-31e78223c131.lovableproject.com?forceHideBadge=true",
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000
    }
  }
};

export default config;
